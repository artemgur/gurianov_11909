﻿namespace ReflectionThreadsTest
{
    public static class Paths
    {
        public const string Tasks = "Exercises";
        public const string Tests = @"Tests\";
        public const string Variants = @"Variants";
        public const string Students = @"Students\";
    }
}