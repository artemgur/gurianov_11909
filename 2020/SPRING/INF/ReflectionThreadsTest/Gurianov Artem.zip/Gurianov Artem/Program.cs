﻿namespace ReflectionThreadsTest
{
    internal class Program
    {
        public static void Main()
        {
            TestSystem.Initialize();
            TestSystem.Run(3);
        }
    }
}