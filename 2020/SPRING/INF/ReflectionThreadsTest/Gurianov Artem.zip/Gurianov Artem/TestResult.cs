﻿namespace ReflectionThreadsTest
{
    public enum TestResult
    {
        Passed,
        WrongResult,
        NoClassOrMethod,
        Exception,
        NotDone
    }
}